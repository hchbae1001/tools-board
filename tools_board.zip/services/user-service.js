let pool = require('../config/pool');
let userQuery = require('../query/userQuery');
async function getUser(){

}

async function getUsers(){

}

async function insertUser(){

}

async function updateUser(){

}

async function deleteUser(){

}

module.exports ={
    getUser:getUser,
    getUsers:getUsers,
    insertUser:insertUser,
    updateUser:updateUser,
    deleteUser:deleteUser
}